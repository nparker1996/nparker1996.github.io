This is a project that I started over the summer of 2016.
I did this to learn more about different forms of artificial intelligence (AI).
I used the classic game of Chess as my base because it shows strategy with very little randomness to it.
I built both the Chess base and the several different forms of AI seen within this project.

This is owned by Noah D. Parker
All Rights Reserved